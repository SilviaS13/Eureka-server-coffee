package com.coffeemaker.coffeeManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeeManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoffeeManagerApplication.class, args);
	}
}
