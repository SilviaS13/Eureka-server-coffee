package com.coffeemaker.coffeeChief;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeeChiefApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoffeeChiefApplication.class, args);
	}
}
